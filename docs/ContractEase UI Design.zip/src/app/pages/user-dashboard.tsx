import { useNavigate } from "react-router";
import { Plus } from "lucide-react";
import { Button } from "../components/ui/button";
import { Navbar } from "../components/navbar";
import { ContractCard } from "../components/contract-card";

// Mock data
const draftContracts = [
  {
    id: "1",
    title: "Service Agreement - Website Development",
    client: "Acme Corp",
    date: "Feb 15, 2026",
    status: "draft" as const,
  },
  {
    id: "2",
    title: "NDA - Product Launch",
    client: "Tech Innovations Inc",
    date: "Feb 14, 2026",
    status: "draft" as const,
  },
];

const pendingContracts = [
  {
    id: "3",
    title: "Employment Contract - Senior Developer",
    client: "Digital Solutions LLC",
    date: "Feb 13, 2026",
    status: "pending" as const,
  },
  {
    id: "4",
    title: "Consulting Agreement",
    client: "StartupXYZ",
    date: "Feb 12, 2026",
    status: "pending" as const,
  },
];

const signedContracts = [
  {
    id: "5",
    title: "Partnership Agreement",
    client: "Global Enterprises",
    date: "Feb 10, 2026",
    status: "signed" as const,
  },
  {
    id: "6",
    title: "License Agreement - Software",
    client: "CloudTech Co",
    date: "Feb 8, 2026",
    status: "signed" as const,
  },
];

export default function UserDashboard() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar title="User Dashboard" showLogout={true} />

      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Welcome Section */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            Welcome back, John
          </h1>
          <p className="text-gray-600">
            Manage your contracts and create new agreements
          </p>
        </div>

        {/* Create New Contract Button */}
        <Button
          onClick={() => navigate("/create-contract")}
          className="w-full mb-6 bg-blue-600 hover:bg-blue-700 flex items-center justify-center gap-2"
          size="lg"
        >
          <Plus className="w-5 h-5" />
          Create New Contract
        </Button>

        {/* Draft Contracts */}
        <section className="mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-3">
            Draft Contracts
          </h2>
          <div className="space-y-3">
            {draftContracts.length > 0 ? (
              draftContracts.map((contract) => (
                <ContractCard key={contract.id} {...contract} type="user" />
              ))
            ) : (
              <p className="text-gray-500 text-sm bg-white rounded-lg p-4 border border-gray-200">
                No draft contracts
              </p>
            )}
          </div>
        </section>

        {/* Pending Contracts */}
        <section className="mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-3">
            Pending Contracts
          </h2>
          <div className="space-y-3">
            {pendingContracts.length > 0 ? (
              pendingContracts.map((contract) => (
                <ContractCard key={contract.id} {...contract} type="user" />
              ))
            ) : (
              <p className="text-gray-500 text-sm bg-white rounded-lg p-4 border border-gray-200">
                No pending contracts
              </p>
            )}
          </div>
        </section>

        {/* Signed Contracts */}
        <section>
          <h2 className="text-lg font-semibold text-gray-900 mb-3">
            Signed Contracts
          </h2>
          <div className="space-y-3">
            {signedContracts.length > 0 ? (
              signedContracts.map((contract) => (
                <ContractCard key={contract.id} {...contract} type="user" />
              ))
            ) : (
              <p className="text-gray-500 text-sm bg-white rounded-lg p-4 border border-gray-200">
                No signed contracts
              </p>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
